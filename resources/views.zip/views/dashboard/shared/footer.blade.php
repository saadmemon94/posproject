<footer class="c-footer">
  <div><a href="https://phoenixtechnologies.co">Phoenix Technologies</a> &copy; 2020 phoenixtechnologies.</div>
</footer>