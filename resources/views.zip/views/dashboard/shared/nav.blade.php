      <div class="c-sidebar-brand"><img class="c-sidebar-brand-full" src="/assets/img/alsyedstorelogo.png" width="80" height="63" alt="Al-Syed Logo"><img class="c-sidebar-brand-minimized" src="assets/img/alsyedstorelogo.png" width="80" height="63" alt="Al-Syed Logo"></div>
      {{-- width="118" height="46" --}}
      <nav class="c-sidebar-nav">
        <ul class="c-nav">
          <li class="c-nav-item"><a class="c-nav-link" href="/">
              <svg class="c-nav-icon">
                <use xlink:href="/assets/icons/coreui/free-symbol-defs.svg#cui-speedometer"></use>
              </svg> Dashboard<span class="badge badge-info">NEW</span></a></li>

              <li class="c-nav-item"><a class="c-nav-link" href="/login" target="_top">
                  <svg class="c-nav-icon">
                    <use xlink:href="/assets/icons/coreui/free-symbol-defs.svg#cui-account-logout"></use>
                  </svg> Login</a></li>
              <li class="c-nav-item"><a class="c-nav-link" href="/register" target="_top">
                  <svg class="c-nav-icon">
                    <use xlink:href="/assets/icons/coreui/free-symbol-defs.svg#cui-account-logout"></use>
                  </svg> Register</a></li>
        </ul>
      </nav>
      <button class="c-sidebar-minimizer c-class-toggler" type="button" data-target="_parent" data-class="c-sidebar-minimized"></button>
    </div>